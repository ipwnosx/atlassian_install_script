# atlassian_install_script
easy way to configure atlassian software within a shell script
